package com.pikaremake.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    // Register a module
    public void register(Module module) {
        if (module == null) {
            throw new IllegalArgumentException(
                    "Module cannot be null"
            );
        }

        if (getModule(module.getName()).isPresent()) {
            throw new IllegalArgumentException(
                    "Module already registered: "
                            + module.getName()
            );
        }

        modules.add(module);
    }

    // Register multiple modules
    public void registerAll(Module... newModules) {
        for (Module module : newModules) {
            register(module);
        }
    }

    // Get all registered modules
    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    // Find module by name
    public Optional<Module> getModule(String name) {
        if (name == null) {
            return Optional.empty();
        }

        return modules.stream()
                .filter(module ->
                        module.getName()
                                .equalsIgnoreCase(name))
                .findFirst();
    }

    // Enable or disable a module
    public boolean toggleModule(String name) {
        Optional<Module> module = getModule(name);

        if (module.isEmpty()) {
            return false;
        }

        module.get().toggle();
        return true;
    }

    // Count registered modules
    public int getModuleCount() {
        return modules.size();
    }
}