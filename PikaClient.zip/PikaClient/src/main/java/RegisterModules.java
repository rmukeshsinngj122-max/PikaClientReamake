package com.pikaremake;

import com.pikaremake.module.ModuleManager;
import com.pikaremake.module.TrainingAim;
import com.pikaremake.module.Sprint;

public class RegisterModules {

    public static final ModuleManager MODULES =
            new ModuleManager();

    public static void registerModules() {
        MODULES.registerAll(
                new TrainingAim(),
                new Sprint()
        );
    }
}