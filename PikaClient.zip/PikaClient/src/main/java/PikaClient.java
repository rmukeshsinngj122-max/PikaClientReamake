package com.pikaclient;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.minecraft.client.option.KeyBinding;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import com.pikaremake.gui.ClickGUI;
import com.example.module.ModuleManager;
import com.pikaremake.RegisterModules;

public class PikaClient implements ClientModInitializer {
    public static final String MOD_ID = "pikaclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static final KeyBinding KEYMAPPING = KeyBindingHelper.registerKeyBinding(new KeyBinding(
        "key.pikaclient.open_gui",
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_RIGHT_SHIFT,
        "key.category.pikaclient"
    ));

    @Override
    public void onInitializeClient() {
        LOGGER.info("Pika Custom Client initialized successfully!");
        RegisterModules.registerModules();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (KEYMAPPING.consumeClick()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGUI(RegisterModules.MODULES.getModules()));
                }
            }
        });
    }
}
