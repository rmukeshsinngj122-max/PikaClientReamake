package com.pikaremake.module;

import net.minecraft.client.Minecraft;

public class Sprint extends Module {

    private final Minecraft mc = Minecraft.getInstance();

    public Sprint() {
        super("Sprint");
    }

    public void tick() {
        if (!isEnabled() || mc.player == null) {
            return;
        }

        if (mc.player.input.forwardImpulse > 0) {
            mc.player.setSprinting(true);
        }
    }
}