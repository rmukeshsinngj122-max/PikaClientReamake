package com.pikaremake.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class TrainingAim extends Module {

    private final Minecraft mc = Minecraft.getInstance();

    private LivingEntity trainingTarget;

    public TrainingAim() {
        super("TrainingAim");
    }

    public LivingEntity getTrainingTarget() {
        return trainingTarget;
    }

    public void tick() {
        if (!isEnabled() || mc.player == null || mc.level == null) {
            trainingTarget = null;
            return;
        }

        Entity entity = mc.crosshairPickEntity;

        if (entity instanceof LivingEntity living
                && entity != mc.player
                && living.isAlive()) {
            trainingTarget = living;
        } else {
            trainingTarget = null;
        }
    }

    public boolean hasTrainingTarget() {
        return trainingTarget != null;
    }

    public String getTargetName() {
        if (trainingTarget == null) {
            return "No target";
        }

        return trainingTarget.getName().getString();
    }

    public float getTargetHealth() {
        if (trainingTarget == null) {
            return 0.0F;
        }

        return trainingTarget.getHealth();
    }
}