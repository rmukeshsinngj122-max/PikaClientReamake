package com.pikaremake.gui;

import com.pikaremake.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {

    private final List<Module> modules;
    private final Minecraft mc = Minecraft.getInstance();

    private int panelX = 20;
    private int panelY = 30;
    private final int panelWidth = 180;
    private final int rowHeight = 24;

    public ClickGUI(List<Module> modules) {
        super(Component.literal("PikaRemake"));
        this.modules = new ArrayList<>(modules);
    }

    @Override
    protected void init() {
        // The GUI uses custom drawing and mouse handling.
    }

    @Override
    public void render(
            GuiGraphics graphics,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        renderBackground(graphics, mouseX, mouseY, partialTick);

        // Main panel
        graphics.fill(
                panelX,
                panelY,
                panelX + panelWidth,
                panelY + 30,
                0xFF202020
        );

        graphics.drawString(
                font,
                "PikaRemake",
                panelX + 8,
                panelY + 10,
                0xFFFFFFFF
        );

        int y = panelY + 30;

        for (Module module : modules) {
            boolean hovered =
                    mouseX >= panelX
                    && mouseX <= panelX + panelWidth
                    && mouseY >= y
                    && mouseY < y + rowHeight;

            int background = module.isEnabled()
                    ? 0xFF245C36
                    : 0xFF303030;

            if (hovered) {
                background = module.isEnabled()
                        ? 0xFF327B49
                        : 0xFF454545;
            }

            graphics.fill(
                    panelX,
                    y,
                    panelX + panelWidth,
                    y + rowHeight,
                    background
            );

            String label = module.getName()
                    + (module.isEnabled() ? " [ON]" : " [OFF]");

            graphics.drawString(
                    font,
                    label,
                    panelX + 8,
                    y + 8,
                    0xFFFFFFFF
            );

            y += rowHeight;
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        int firstRowY = panelY + 30;

        for (int i = 0; i < modules.size(); i++) {
            int rowY = firstRowY + i * rowHeight;

            boolean inside =
                    mouseX >= panelX
                    && mouseX <= panelX + panelWidth
                    && mouseY >= rowY
                    && mouseY < rowY + rowHeight;

            if (inside) {
                modules.get(i).toggle();
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}